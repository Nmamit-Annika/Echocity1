import React, { useState, useRef, useEffect } from 'react';
import { Send, Map, Search, MapPin, Info, Bot, Camera, Mic, X, Image as ImageIcon } from 'lucide-react';
import { ChatMessage, Sender, ModelType, LocationData } from './types';
import { sendMessageToGemini } from './services/geminiService';
import { ChatMessageBubble } from './components/ChatMessageBubble';

export default function App() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      text: "Hello! I'm your Civic Assistant. I can help you find local government offices, parks, and answer questions about civic issues or policies. \n\nTry asking: *\"Where is the nearest post office?\"* or *\"What are the recycling rules here?\"*",
      sender: Sender.Bot,
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [location, setLocation] = useState<LocationData | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  
  // Settings / Toggles
  const [useSearch, setUseSearch] = useState(true);
  const [useMaps, setUseMaps] = useState(true);
  const [modelType, setModelType] = useState<ModelType>(ModelType.Flash);

  // New State for Attachments & Speech
  const [selectedImage, setSelectedImage] = useState<{data: string, mimeType: string} | null>(null);
  const [isListening, setIsListening] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Speech Recognition Ref
  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = false;
        recognitionRef.current.interimResults = false;
        
        recognitionRef.current.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript;
            setInput(prev => prev + (prev ? ' ' : '') + transcript);
            setIsListening(false);
        };

        recognitionRef.current.onerror = (event: any) => {
            console.error("Speech recognition error", event.error);
            setIsListening(false);
        };
        
        recognitionRef.current.onend = () => {
            setIsListening(false);
        };
    }
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Request location on mount
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
          setLocationError(null);
        },
        (error) => {
          console.warn("Location access denied or error:", error);
          setLocationError("Location access needed for 'nearby' searches.");
        }
      );
    } else {
      setLocationError("Geolocation not supported by this browser.");
    }
  }, []);

  const toggleListening = () => {
    if (!recognitionRef.current) {
        alert("Speech recognition is not supported in this browser.");
        return;
    }
    
    if (isListening) {
        recognitionRef.current.stop();
    } else {
        recognitionRef.current.start();
        setIsListening(true);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const base64String = reader.result as string;
              // Remove the data URL prefix (e.g. "data:image/jpeg;base64,")
              const base64Data = base64String.split(',')[1];
              setSelectedImage({
                  data: base64Data,
                  mimeType: file.type
              });
          };
          reader.readAsDataURL(file);
      }
  };

  const handleSend = async () => {
    if ((!input.trim() && !selectedImage) || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      text: input,
      sender: Sender.User,
      timestamp: Date.now(),
      attachment: selectedImage ? { ...selectedImage } : undefined
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    const currentImage = selectedImage; // Capture for API call
    setSelectedImage(null); // Clear immediately
    setIsLoading(true);

    try {
      // Prepare history for API - now including inline data if present in past messages
      const history = messages.map(m => {
         const parts: any[] = [];
         if (m.attachment) {
             parts.push({ inlineData: { mimeType: m.attachment.mimeType, data: m.attachment.data } });
         }
         if (m.text) {
             parts.push({ text: m.text });
         }
         return {
            role: m.sender === Sender.User ? 'user' : 'model',
            parts: parts
         };
      });

      // Force Flash model if Maps/Search are used OR if multimodal input is present
      const activeModel = (useMaps || useSearch || currentImage) ? ModelType.Flash : modelType;

      const response = await sendMessageToGemini({
        prompt: userMsg.text,
        model: activeModel,
        history: history,
        useSearch: useSearch,
        useMaps: useMaps,
        location: location,
        image: currentImage
      });

      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: response.text,
        sender: Sender.Bot,
        timestamp: Date.now(),
        groundingChunks: response.groundingChunks
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: "Sorry, I encountered an error. Please try again.",
        sender: Sender.Bot,
        timestamp: Date.now(),
        isError: true
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 relative">
      
      {/* Header */}
      <header className="flex-none bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between shadow-sm z-10">
        <div className="flex items-center gap-3">
          <div className="bg-teal-600 p-2 rounded-lg">
            <MapPin className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">CivicConnect</h1>
            <p className="text-xs text-slate-500">Powered by Gemini</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           {/* Location Status Indicator */}
           <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full border border-slate-200">
             <div className={`w-2 h-2 rounded-full ${location ? 'bg-green-500' : 'bg-orange-400'}`}></div>
             <span className="text-xs text-slate-600 font-medium">
               {location ? 'Location Active' : 'Location Inactive'}
             </span>
           </div>
        </div>
      </header>

      {/* Main Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-6 scrollbar-hide">
        <div className="max-w-3xl mx-auto">
          {messages.map((msg) => (
            <ChatMessageBubble key={msg.id} message={msg} />
          ))}
          {isLoading && (
            <div className="flex w-full mb-6 justify-start animate-pulse">
              <div className="flex flex-row">
                 <div className="flex-shrink-0 h-8 w-8 rounded-full bg-teal-600 mr-3 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                 </div>
                 <div className="bg-white border border-slate-100 p-4 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                 </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer className="flex-none bg-white border-t border-slate-200 p-4 md:p-6">
        <div className="max-w-3xl mx-auto space-y-4">
          
          {/* Controls / Toggles */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg">
               <button
                 onClick={() => setModelType(ModelType.Flash)}
                 className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${modelType === ModelType.Flash ? 'bg-white text-teal-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
               >
                 Fast (Flash)
               </button>
               <button
                 onClick={() => setModelType(ModelType.Pro)}
                 className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${modelType === ModelType.Pro ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
               >
                 Deep (Pro)
               </button>
            </div>

            <div className="flex items-center gap-2">
              <button 
                onClick={() => setUseMaps(!useMaps)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${useMaps ? 'bg-green-50 border-green-200 text-green-700' : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'}`}
                title="Use Google Maps data for location queries"
              >
                <Map className="w-3.5 h-3.5" />
                Maps {useMaps ? 'On' : 'Off'}
              </button>
              
              <button 
                onClick={() => setUseSearch(!useSearch)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${useSearch ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'}`}
                title="Use Google Search for current info"
              >
                <Search className="w-3.5 h-3.5" />
                Search {useSearch ? 'On' : 'Off'}
              </button>
            </div>
          </div>

          {/* Image Preview (if selected) */}
          {selectedImage && (
            <div className="relative inline-block">
               <img 
                 src={`data:${selectedImage.mimeType};base64,${selectedImage.data}`} 
                 alt="Selected" 
                 className="h-20 w-auto rounded-lg border border-slate-200 shadow-sm"
               />
               <button 
                 onClick={() => setSelectedImage(null)}
                 className="absolute -top-2 -right-2 bg-slate-800 text-white rounded-full p-0.5 shadow-md hover:bg-slate-700"
               >
                 <X className="w-3.5 h-3.5" />
               </button>
            </div>
          )}

          {/* Input Container */}
          <div className="relative flex items-end gap-2 bg-white border border-slate-300 rounded-xl shadow-sm focus-within:ring-2 focus-within:ring-teal-500 focus-within:border-transparent transition-shadow p-2">
            
            {/* Hidden File Input */}
            <input
                type="file"
                accept="image/*"
                className="hidden"
                ref={fileInputRef}
                onChange={handleImageSelect}
                capture="environment"
            />

            {/* Attachment & Mic Buttons */}
            <div className="flex flex-col gap-1 mb-1">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="p-2 text-slate-400 hover:text-teal-600 hover:bg-teal-50 rounded-lg transition-colors"
                title="Upload or Capture Image"
              >
                <Camera className="w-5 h-5" />
              </button>
              <button
                onClick={toggleListening}
                className={`p-2 rounded-lg transition-colors ${isListening ? 'text-red-500 bg-red-50 animate-pulse' : 'text-slate-400 hover:text-teal-600 hover:bg-teal-50'}`}
                title="Speech to Text"
              >
                <Mic className="w-5 h-5" />
              </button>
            </div>

            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={isListening ? "Listening..." : "Ask about civic issues (attach photos for analysis)..."}
              className="w-full max-h-32 min-h-[50px] bg-transparent border-none focus:ring-0 resize-none py-3 px-2 text-slate-800 placeholder-slate-400 text-sm"
              rows={1}
            />
            <button
              onClick={handleSend}
              disabled={(isLoading || (!input.trim() && !selectedImage))}
              className="flex-shrink-0 mb-1 p-3 bg-teal-600 text-white rounded-lg hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isLoading ? (
                 <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                 <Send className="w-5 h-5" />
              )}
            </button>
          </div>
          
          {/* Disclaimer / Info */}
          <div className="flex items-center justify-center gap-1 text-[10px] text-slate-400">
            <Info className="w-3 h-3" />
            <p>AI can make mistakes. Verify important civic information with official sources.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}