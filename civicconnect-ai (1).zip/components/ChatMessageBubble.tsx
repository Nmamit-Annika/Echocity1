import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Sender, ChatMessage, GroundingChunk } from '../types';
import { User, Bot, MapPin, Globe, AlertCircle } from 'lucide-react';
import clsx from 'clsx';

interface ChatMessageBubbleProps {
  message: ChatMessage;
}

export const ChatMessageBubble: React.FC<ChatMessageBubbleProps> = ({ message }) => {
  const isUser = message.sender === Sender.User;

  const renderGroundingSource = (chunk: GroundingChunk, index: number) => {
    if (chunk.web) {
      return (
        <a 
          key={`web-${index}`}
          href={chunk.web.uri}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 p-2 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg text-xs text-blue-800 transition-colors mb-1"
        >
          <Globe className="w-3 h-3 flex-shrink-0" />
          <span className="truncate max-w-[200px]">{chunk.web.title || chunk.web.uri}</span>
        </a>
      );
    }
    if (chunk.maps) {
      return (
        <a 
          key={`map-${index}`}
          href={chunk.maps.uri}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 p-2 bg-green-50 hover:bg-green-100 border border-green-200 rounded-lg text-xs text-green-800 transition-colors mb-1"
        >
          <MapPin className="w-3 h-3 flex-shrink-0" />
          <span className="truncate max-w-[200px]">{chunk.maps.title || "View on Maps"}</span>
        </a>
      );
    }
    return null;
  };

  return (
    <div className={clsx("flex w-full mb-6", isUser ? "justify-end" : "justify-start")}>
      <div className={clsx("flex max-w-[85%] md:max-w-[70%]", isUser ? "flex-row-reverse" : "flex-row")}>
        
        {/* Avatar */}
        <div className={clsx(
          "flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center mt-1",
          isUser ? "bg-indigo-600 ml-3" : "bg-teal-600 mr-3"
        )}>
          {isUser ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
        </div>

        {/* Bubble */}
        <div className={clsx(
          "flex flex-col p-4 rounded-2xl shadow-sm",
          isUser 
            ? "bg-indigo-600 text-white rounded-tr-none" 
            : "bg-white border border-slate-100 text-slate-800 rounded-tl-none"
        )}>
          {/* Attachment Image */}
          {message.attachment && (
             <div className="mb-3 rounded-lg overflow-hidden bg-black/5">
                <img 
                  src={`data:${message.attachment.mimeType};base64,${message.attachment.data}`} 
                  alt="User upload" 
                  className="max-w-full h-auto max-h-60 object-cover"
                />
             </div>
          )}

          {message.isError ? (
            <div className="flex items-center gap-2 text-red-200">
              <AlertCircle className="w-4 h-4" />
              <span>Error sending message. Please try again.</span>
            </div>
          ) : (
            <div className={clsx("prose prose-sm max-w-none break-words", isUser ? "prose-invert" : "text-slate-700")}>
              <ReactMarkdown>{message.text}</ReactMarkdown>
            </div>
          )}

          {/* Grounding Sources (Only for Bot) */}
          {!isUser && message.groundingChunks && message.groundingChunks.length > 0 && (
            <div className="mt-4 pt-3 border-t border-slate-100">
              <p className="text-[10px] uppercase tracking-wider font-semibold text-slate-400 mb-2">Sources & Locations</p>
              <div className="flex flex-wrap gap-2">
                {message.groundingChunks.map((chunk, idx) => renderGroundingSource(chunk, idx))}
              </div>
            </div>
          )}
          
          <span className={clsx("text-[10px] mt-2 block opacity-60", isUser ? "text-indigo-200" : "text-slate-400")}>
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
    </div>
  );
};