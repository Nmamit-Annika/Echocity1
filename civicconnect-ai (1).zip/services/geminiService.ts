import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ModelType, LocationData } from "../types";

// Initialize the client. API_KEY is guaranteed to be in process.env per instructions.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface GenerateResponseParams {
  prompt: string;
  model: ModelType;
  history?: { role: string; parts: { text?: string; inlineData?: { mimeType: string; data: string } }[] }[];
  useSearch?: boolean;
  useMaps?: boolean;
  location?: LocationData | null;
  image?: { data: string; mimeType: string } | null;
}

export const sendMessageToGemini = async ({
  prompt,
  model,
  history = [],
  useSearch = false,
  useMaps = false,
  location,
  image
}: GenerateResponseParams): Promise<{ text: string; groundingChunks?: any[] }> => {
  
  const tools: any[] = [];
  if (useSearch) {
    tools.push({ googleSearch: {} });
  }
  if (useMaps) {
    tools.push({ googleMaps: {} });
  }

  const config: any = {
    systemInstruction: "You are a knowledgeable and helpful civic assistant. Your goal is to help users find information about their local area, understand civic issues, government policies, and locate amenities or offices. \n\n**AI Categorization & Analysis:**\nIf the user provides an image or describes a civic issue (like a pothole, graffiti, trash, infrastructure damage, etc.):\n1.  Analyze the visual or textual details carefully.\n2.  Start your response with a bold category tag, e.g., **[Category: Infrastructure]** or **[Category: Sanitation]**.\n3.  Provide specific advice on how to report or resolve the issue.\n\nWhen users ask about locations, use the Google Maps tool. When users ask about current events or specific regulations, use Google Search. Be concise, polite, and accurate. Format your response in Markdown.",
  };

  if (tools.length > 0) {
    config.tools = tools;
  }

  // Add location context if available and maps are being used
  if (useMaps && location) {
    config.toolConfig = {
      retrievalConfig: {
        latLng: {
          latitude: location.latitude,
          longitude: location.longitude
        }
      }
    };
  }

  // Construct parts for the current user message
  const currentUserParts: any[] = [];
  
  if (image) {
    currentUserParts.push({
      inlineData: {
        mimeType: image.mimeType,
        data: image.data
      }
    });
  }
  
  if (prompt) {
    currentUserParts.push({ text: prompt });
  }

  // Construct full contents with history
  const contents = [
    ...history.map(msg => ({
      role: msg.role,
      parts: msg.parts
    })),
    {
      role: 'user',
      parts: currentUserParts
    }
  ];

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: contents,
      config: config
    });

    const text = response.text || "I couldn't generate a text response.";
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

    return { text, groundingChunks };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};