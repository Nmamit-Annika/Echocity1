export enum Sender {
  User = 'user',
  Bot = 'model'
}

export interface GroundingChunk {
  web?: {
    uri?: string;
    title?: string;
  };
  maps?: {
    uri?: string;
    title?: string;
    placeAnswerSources?: {
      reviewSnippets?: {
        content?: string;
      }[];
    }[];
  };
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: Sender;
  timestamp: number;
  isError?: boolean;
  groundingChunks?: GroundingChunk[];
  attachment?: {
    data: string; // Base64 string
    mimeType: string;
  };
}

export enum ModelType {
  Flash = 'gemini-2.5-flash',
  Pro = 'gemini-3-pro-preview'
}

export interface LocationData {
  latitude: number;
  longitude: number;
}